#include <iostream>
using namespace std;

int main() {
    double feet = 10.0; // You can change this value
    double meters = feet * 0.305;

    cout << feet << " feet is " << meters << " meters." << endl;
    return 0;
}
