#include <iostream>
using namespace std;

int main() {
    cout << "D D D D D    M       M" << endl;
    cout << "D        D   MM     MM" << endl;
    cout << "D        D   M M   M M" << endl;
    cout << "D        D   M  M M  M" << endl;
    cout << "D        D   M   M   M" << endl;
    cout << "D        D   M       M" << endl;
    cout << "D        D   M       M" << endl;
    cout << "D D D D D    M       M" << endl;
    return 0;
}
