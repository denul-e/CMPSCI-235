#include <iostream>
using namespace std;

int main() {
    double celsius = 100.0; // You can change this value
    double fahrenheit = (9.0 / 5.0) * celsius + 32.0;
    cout << "Celsius: " << celsius << "°C" << endl;
    cout << "Fahrenheit: " << fahrenheit << "°F" << endl;
    return 0;
}
