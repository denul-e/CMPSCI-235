#include <iostream>
using namespace std;

int main() {
    cout << "  C C     O O        C C" << endl;
    cout << "C       O     O    C" << endl;
    cout << "C       O     O    C" << endl;
    cout << "  C C     O O        C C" << endl;
    return 0;
}
